import numpy as np
import argparse
from scipy.stats import linregress
from scipy.signal import firwin, butter, cheby1, lfiltic, lfilter, resample_poly
import torch

class CustomSVDs:
    def __init__(self, seq, device):
        self.Z, self.H, self.W, self.T = seq.shape
        self.flat_seq = torch.from_numpy(seq).reshape(self.Z*self.H*self.W, self.T).to(device, dtype=torch.float32)

    def reconstructSVD(self, svd, tissue_th, noise_th, shape):
        U, S, Vh = svd
        S = S.to(torch.complex128)
        mask = S.clone()
        mask[:tissue_th] = 0
        mask[noise_th:] = 0
        filtered_seq = U @ torch.diag(mask) @ Vh
        return self.unflatten(filtered_seq, shape)

    def SVD(self, tissue_upper_th, noise_th, tissue_lower_th=1, batch_size=None):
        if not batch_size:
            batch_size = self.Z * self.H * self.W

        filtered_flat = torch.zeros_like(self.flat_seq)

        for start in range(0, self.Z*self.H*self.W, batch_size):
            end = min(start + batch_size, self.Z*self.H*self.W)
            batch = self.flat_seq[start:end, :]

            U, S, Vh = torch.linalg.svd(batch, full_matrices=False)

            if tissue_upper_th > 0:
                S[tissue_lower_th:tissue_upper_th] = 0
            if noise_th > 0:
                S[noise_th:] = 0

            filtered_batch = U @ torch.diag(S) @ Vh
            filtered_flat[start:end, :] = filtered_batch

        filtered_array = filtered_flat.reshape(self.Z, self.H, self.W, self.T).cpu().numpy()
        return filtered_array

    def randSVD(self, tissue_th, d, iters):
        '''
        Params:
            tissue_th (int): expected singular value threshold for tissue
            d: 
            iters: 
        '''
        t = self.flat_seq.shape[1]
        omega = torch.randn(t, tissue_th+d)

        S_prime = self.flat_seq @ omega
        Q, _ = torch.linalg.qr(S_prime)

        for _ in range(iters):
            conjugate = torch.conj(self.flat_seq)
            Qi, _ = torch.linalg.qr(torch.t(conjugate)@Q)
            Q, _ = torch.linalg.qr(self.flat_seq@Qi)

        conjugate = torch.conj(Q)
        A = torch.t(conjugate) @ self.flat_seq
        tissue_clutter = Q @ A

        filtered_seq = self.flat_seq - tissue_clutter
        return self.unflatten(filtered_seq, self.seq.shape)
    
    def adaptiveSVD(self, tissue_th, noise_th, block_size, block_overlap, PRF=500):
        '''
        Params:
            tissue_th (int): expected singular value threshold for tissue
            noise_th: 
            block_size: 
            block_overlap:
            PRF (int): pulse repetition frequency (Hz?)
        '''
        period = 1 / PRF

        step = block_size - block_overlap
        num_blocks_x = (self.shape[0] - block_size) // step + 1
        num_blocks_z = (self.shape[1] - block_size) // step + 1

        filtered_seq = torch.zeros(self.shape, dtype='complex128')
        coverage_map = torch.ones(self.shape, dtype=int)

        for i in range(0, num_blocks_x, step):
            for j in range(0, num_blocks_z, step):

                coverage_map[i:i+block_size, j:j+block_size, :] += 1
                block = self.seq[i:i+block_size, j:j+block_size, :]
                flat_block = self.flatten(block, self.seq.shape[-1])

                (U, S, Vh) = torch.linalg.svd(flat_block, full_matrices=False)

                logS = 10 * torch.log10(S/np.max(S))
                second_derivative = torch.diff(logS, n=2)
                elbow_index = torch.argmax(second_derivative) + 1
                th_index = torch.argmax(logS >= tissue_th)

                lower_th = torch.max(elbow_index, th_index)

                V = torch.t(torch.conj(Vh))
                v0 = V[:-1, :]
                v1 = V[1:, :]
                product = v1 * torch.conj(v0)

                numer = torch.sum(torch.imag(product), axis=0)
                denom = torch.sum(torch.real(product), axis=0)
                omega = torch.arctan2(numer, denom) / period
                mean_freqs = torch.abs(omega / (2 * np.pi))

                fitting_point = np.argmax(mean_freqs >= noise_th)

                slope, intercept, *_ = linregress(torch.arange(fitting_point, len(logS)), logS[fitting_point:])
                fitted_slope = slope * torch.arange(len(logS)) + intercept
                diff = np.abs(logS - fitted_slope)

                diff_th = diff.mean() + 2*diff.std()
                upper_th = len(diff) - 1 - np.argmax(diff[::-1] >= diff_th)

                filteredBlock = self.reconstructSVD(U, S, Vh, lower_th, upper_th, block.shape)
                SSum = sum(S[tissue_th:noise_th+1])
                filtered_seq[i:i+block_size, j:j+block_size, :] += filteredBlock/SSum

        filtered_seq /= coverage_map
        return torch.transpose(filtered_seq, (2, 0, 1))
    
    # def adaptive_thresholding(self, S, Vh, tissue_th, noise_th, gradient_th, PRF = 1000):

        
    #     T = 1 / PRF

    #     logS = 20*np.log10(S/np.max(S)+1e-8)

    #     gradient = np.abs(np.gradient(logS))
    #     flatteningIndex = np.argmax(gradient[1:] <= gradient_th)

    #     V = Vh.conj().T

    #     v0 = V[:-1, :]
    #     v1 = V[1:, :]
    #     product = v1 * np.conj(v0)

    #     num = np.sum(np.imag(product), axis=0)
    #     den = np.sum(np.real(product), axis=0)
    #     # mean angular frequency
    #     omega = np.arctan2(num, den) / T
    #     # mean doppler frequency
    #     mean_freqs = np.abs(omega / (2 * np.pi))

    #     thresholdIndex = np.argmax(mean_freqs >= tissueFreqThreshold)
    #     lowerThreshold = max(thresholdIndex, flatteningIndex)

    #     fittingPoint = np.argmax(mean_freqs >= noiseFreqThreshold)
    #     x_vals = np.arange(fittingPoint.item(), len(logS))
    #     y_vals = logS[fittingPoint:]

    #     slope, intercept, *_ = linregress(x_vals, y_vals)

    #     fittedSlope = slope * np.arange(len(logS)) + intercept
    #     diff = np.abs(logS - fittedSlope)

    #     # arbitrary threshold for point of deviation from linear trend
    #     diffThreshold =  2 * np.std(diff)  
        
    #     upperThreshold = len(diff) - 1 - np.argmax(diff[::-1] >= diffThreshold) 

    #     return lowerThreshold, upperThreshold
    

    


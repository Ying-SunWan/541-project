import numpy as np
from svd import *
from numpy.typing import NDArray
import scipy

from sklearn.preprocessing import StandardScaler
import hdbscan
import numpy as np

def load_data(mat_path: str) -> NDArray[np.complex128]:
    mat_data = scipy.io.loadmat(mat_path)
    bf_data = np.array([np.array(f) for f in mat_data['image']])
    return bf_data

def intensity_transform(
    image: NDArray[np.complex128],
    threshold: float = None,
    dynamicRange: float = None,
    gamma: float = 1,
    log: bool = False,
    normalization: bool = False,
    retainPhase: bool = False,
):
    if threshold:
        max_val = 10 ** (threshold/20)
    else:
        max_val = np.max(np.abs(image))

    if dynamicRange:
        min_val = 10 ** ((20*np.log10(max_val)-dynamicRange) / 20)
    else:
        min_val = 0

    image_phase = np.angle(image)

    image = abs(image)
    image = np.clip(image, min_val, max_val)
    
    image = (image-min_val) / (max_val-min_val)

    image = image ** (1/gamma)

    if not normalization:
        image = image * max_val + min_val

    if log:
        image = 20 * np.log10(image+1e-12)

    if retainPhase:
        image = image * np.exp(1j * image_phase)

    return image

def contrast_enhance(seq):
    PD_filtered_svd = [(1/s.shape[2]) * np.sum(s**2, axis=2) for s in seq]
    PD_filtered_svd_contrast = [intensity_transform(pd, threshold=130, dynamicRange=60, log=True) for pd in PD_filtered_svd]
    PD_filtered_svd_contrast = [np.rot90(pd, k=-1) for pd in PD_filtered_svd_contrast]
    PD_filtered_svd_contrast = [np.fliplr(pd) for pd in PD_filtered_svd_contrast]
    return PD_filtered_svd_contrast

def log_compress(seq: NDArray[np.complex128],):
    return 20 * np.log10(np.abs(seq) + 1e-6)

def PD(seq: NDArray[np.complex128]):
    return (1/seq.shape[2]) * np.sum(abs(seq)**2, axis=2)

def attenthese(
    seq: NDArray[np.complex128],
    rng: list[int],
    alpha: list[float]
) -> NDArray:
    alpha *= len(rng)

    N = seq.shape[2]
    for r, a in zip(rng, alpha):
        idx = r - 1
        idx_sym = N - r + 1
        att = 10 ** (-a)
        seq[:, :, idx] *= att
        seq[:, :, idx_sym] *= att

    return seq

def hpfilt(vol):
    fft_seq = np.fft.fft(vol, axis=3);
    fft_seq[:, :, :, 0] *= 1e-15
    fft_seq = np.fft.ifft(fft_seq, axis=3)
    return fft_seq

def cluster_filtering(x, y, z, values, min_cluster_size, min_samples):
    X = np.column_stack([x, y, z, values])
    X_scaled = StandardScaler().fit_transform(X)

    clusterer = hdbscan.HDBSCAN(
        min_cluster_size=min_cluster_size,
        min_samples=min_samples,
        cluster_selection_method='eom'
    )
    labels = clusterer.fit_predict(X_scaled)

    # remove noise
    mask = labels != -1
    cluster_ids, counts = np.unique(labels[mask], return_counts=True)
    cluster_sizes = dict(zip(cluster_ids, counts))
    min_pts = 0.5 * max(cluster_sizes.values())
    keep_clusters = {
        cid for cid, sz in cluster_sizes.items()
        if sz >= min_pts
    }
    keep_mask = np.isin(labels, list(keep_clusters))
    return keep_mask
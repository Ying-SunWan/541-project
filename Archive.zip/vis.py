import plotly.express as px
import plotly.io as pio
import numpy as np
from numpy.typing import NDArray

pio.renderers.default = "browser"

def plot_vol(x, y, z, values, title: str, output_html: str, scale_x: float = 1, scale_y: float = 1, scale_z: float = 1, opacity=0.1) -> None:
    fig = px.scatter_3d(
        x=x,
        y=y,
        z=z,
        color=values,
        opacity=opacity,
        title=title,
        color_continuous_scale='Inferno_r'
    )

    fig.update_layout(
        scene=dict(
            xaxis=dict(
                showgrid=False,
                showbackground=False,
                zeroline=False,
                visible=False
            ),
            yaxis=dict(
                showgrid=False,
                showbackground=False,
                zeroline=False,
                visible=False
            ),
            zaxis=dict(
                showgrid=False,
                showbackground=False,
                zeroline=False,
                visible=False
            ),
            aspectmode="manual",
            aspectratio=dict(x=scale_x, y=scale_y, z=scale_z),
        )
    )


    fig.update_traces(marker=dict(size=1))
    fig.write_html(output_html, auto_open=True)